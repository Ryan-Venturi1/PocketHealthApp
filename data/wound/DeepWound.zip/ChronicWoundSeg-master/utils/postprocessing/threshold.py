# ------------------------------------------------------------ #
#
# file : postprocessing/threshold.py
# author : CM
# Segment image with threshold
#
# ------------------------------------------------------------ #
